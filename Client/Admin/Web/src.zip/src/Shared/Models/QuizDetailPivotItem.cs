﻿namespace SwiftCAPS.Admin.Web.Shared.Models
{
    public enum DetailsPivotType
    {
        General,
        Questions
    }
}
