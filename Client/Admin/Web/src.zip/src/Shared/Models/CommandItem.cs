﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwiftCAPS.Admin.Web.Shared.Models
{
    public enum CommandItem
    {
        None = 0,
        Add = 1,
        Edit = 2,
        Delete = 3,
        Detail = 4
    }
}
